// document.getElementById('back').onclick = function()  {
//     console.log(123)
// }
document.getElementById('back').addEventListener('click', () => {
    window.open('../back.html')
})
document.getElementById('back').click()
